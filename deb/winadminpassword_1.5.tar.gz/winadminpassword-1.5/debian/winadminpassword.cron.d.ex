#
# Regular cron jobs for the winadminpassword package
#
0 4	* * *	root	[ -x /usr/bin/winadminpassword_maintenance ] && /usr/bin/winadminpassword_maintenance
