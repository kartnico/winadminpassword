# Defaults for winadminpassword initscript
# sourced by /etc/init.d/winadminpassword
# installed at /etc/default/winadminpassword by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
